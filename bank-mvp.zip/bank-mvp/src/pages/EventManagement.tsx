import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { events, bankers } from '@/lib/mockData';
import { toast } from 'sonner';


const eventSchema = z.object({
  title: z.string().min(3, 'Title must be at least 3 characters'),
  date: z.string().min(1, 'Date is required'),
  location: z.string().min(3, 'Location is required'),
  criteria: z.object({
    aum: z.number().min(0, 'AUM must be positive'),
    income: z.number().min(0, 'Income must be positive')
  })
});

type EventFormData = z.infer<typeof eventSchema>;

export default function EventManagement() {
  const [activeStep, setActiveStep] = useState(0);
  const [selectedBankers, setSelectedBankers] = useState<string[]>([]);
  const [isBroadcasting, setIsBroadcasting] = useState(false);

  const { register, handleSubmit, formState: { errors }, reset } = useForm<EventFormData>({
    resolver: zodResolver(eventSchema)
  });

  const handleNextStep = () => setActiveStep(prev => prev + 1);
  const handlePrevStep = () => setActiveStep(prev => prev - 1);

  const onSubmit = (data: EventFormData) => {
    console.log('Event created:', data);
    reset();
    setActiveStep(0);
  };

  const toggleBankerSelection = (id: string) => {
    setSelectedBankers(prev => 
      prev.includes(id) ? prev.filter(b => b !== id) : [...prev, id]
    );
  };

  const broadcastEvent = () => {
    setIsBroadcasting(true);
    setTimeout(() => {
      setIsBroadcasting(false);
      setSelectedBankers([]);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <h1 className="text-2xl font-semibold text-[#002366] mb-8">Event Management</h1>
          
          {/* Event Creation Wizard */}
          <div className="bg-white rounded-lg shadow p-6 mb-8">
            <h2 className="text-lg font-medium text-[#002366] mb-4">Create New Event</h2>
            <div className="flex mb-6">
              {['Basic Info', 'Criteria', 'Review'].map((step, index) => (
                <div key={step} className="flex items-center">
                  <div 
                    className={`w-8 h-8 rounded-full flex items-center justify-center 
                      ${index <= activeStep ? 'bg-[#002366] text-white' : 'bg-gray-200'}`}
                  >
                    {index + 1}
                  </div>
                  <div className={`ml-2 ${index === activeStep ? 'font-medium' : ''}`}>{step}</div>
                  {index < 2 && <div className="mx-2 w-8 h-px bg-gray-300"></div>}
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit(onSubmit)}>
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: activeStep === 0 ? -20 : 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
              >
                {activeStep === 0 && (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Event Title</label>
                      <input
                        type="text"
                        {...register('title')}
                        className={`w-full p-2 border rounded ${errors.title ? 'border-red-500' : 'border-gray-300'}`}
                      />
                      {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title.message}</p>}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                        <input
                          type="date"
                          {...register('date')}
                          className={`w-full p-2 border rounded ${errors.date ? 'border-red-500' : 'border-gray-300'}`}
                        />
                        {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date.message}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                        <input
                          type="text"
                          {...register('location')}
                          className={`w-full p-2 border rounded ${errors.location ? 'border-red-500' : 'border-gray-300'}`}
                        />
                        {errors.location && <p className="text-red-500 text-xs mt-1">{errors.location.message}</p>}
                      </div>
                    </div>
                  </div>
                )}

                {activeStep === 1 && (
                  <div className="space-y-4">
                    <h3 className="font-medium text-gray-700">Client Criteria</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Minimum AUM (SGD)</label>
                        <input
                          type="number"
                          {...register('criteria.aum', { valueAsNumber: true })}
                          className={`w-full p-2 border rounded ${errors.criteria?.aum ? 'border-red-500' : 'border-gray-300'}`}
                        />
                        {errors.criteria?.aum && <p className="text-red-500 text-xs mt-1">{errors.criteria.aum.message}</p>}
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Minimum Income (SGD)</label>
                        <input
                          type="number"
                          {...register('criteria.income', { valueAsNumber: true })}
                          className={`w-full p-2 border rounded ${errors.criteria?.income ? 'border-red-500' : 'border-gray-300'}`}
                        />
                        {errors.criteria?.income && <p className="text-red-500 text-xs mt-1">{errors.criteria.income.message}</p>}
                      </div>
                    </div>
                  </div>
                )}

                {activeStep === 2 && (
                  <div className="space-y-4">
                    <h3 className="font-medium text-gray-700">Review Event Details</h3>
                    <div className="bg-gray-50 p-4 rounded">
                      <p className="text-sm text-gray-600">Review your event details before submission</p>
                    </div>
                  </div>
                )}
              </motion.div>

              <div className="flex justify-between mt-6">
                <button
                  type="button"
                  onClick={handlePrevStep}
                  disabled={activeStep === 0}
                  className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium disabled:opacity-50"
                >
                  Back
                </button>
                {activeStep < 2 ? (
                  <button
                    type="button"
                    onClick={handleNextStep}
                    className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium"
                  >
                    Next
                  </button>
                ) : (
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium"
                  >
                    Create Event
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Event List */}
          <div className="mb-8">
            <h2 className="text-lg font-medium text-[#002366] mb-4">Upcoming Events</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {events.map(event => (
                <div key={event.id} className="bg-white rounded-lg shadow p-4 border-l-4 border-[#002366] relative">
                  <button 
                    onClick={() => toast.success(`Event ${event.title} deleted`)}
                    className="absolute top-2 right-2 text-gray-400 hover:text-red-500"
                  >
                    <i className="fa-solid fa-trash"></i>
                  </button>
                  <h3 className="font-medium text-[#002366]">{event.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{new Date(event.date).toLocaleDateString()}</p>
                  <p className="text-sm text-gray-600">{event.location}</p>
                  <div className="mt-2 pt-2 border-t border-gray-100">
                    <span className="text-xs font-medium text-gray-500">Criteria:</span>
                    <p className="text-xs text-gray-600">AUM ≥ {event.criteria.aum.toLocaleString()} SGD</p>
                    <p className="text-xs text-gray-600">Income ≥ {event.criteria.income.toLocaleString()} SGD</p>
                  </div>
                </div>
              ))}
            </div>

          </div>

          {/* Broadcast Section */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-[#002366] mb-4">Broadcast Event Notification</h2>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Select Bankers</label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
                {bankers.map(banker => (
                  <div 
                    key={banker.id}
                    onClick={() => toggleBankerSelection(banker.id)}
                    className={`p-2 border rounded cursor-pointer text-sm flex items-center 
                      ${selectedBankers.includes(banker.id) ? 'border-[#002366] bg-blue-50' : 'border-gray-300'}`}
                  >
                    <div className={`w-3 h-3 rounded-full mr-2 ${selectedBankers.includes(banker.id) ? 'bg-[#002366]' : 'bg-gray-300'}`}></div>
                    {banker.name}
                  </div>
                ))}
              </div>
            </div>
            <button
              onClick={broadcastEvent}
              disabled={selectedBankers.length === 0 || isBroadcasting}
              className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium disabled:opacity-50"
            >
              {isBroadcasting ? 'Sending...' : 'Broadcast Notification'}
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
