
import { useState, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { clients } from '@/lib/mockData';
import { toast } from 'sonner';

type FilterCriteria = {
  minAum: number;
  minIncome: number;
  regions: string[];
};

export default function ClientNomination() {
  const location = useLocation();
  const navigate = useNavigate();
  const [filteredClients, setFilteredClients] = useState(clients);
  const [selectedClients, setSelectedClients] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const itemsPerPage = 5;

  const { register, watch } = useForm<FilterCriteria>({
    defaultValues: {
      minAum: 0,
      minIncome: 0,
      regions: ['Singapore', 'Malaysia', 'Indonesia', 'Thailand']
    }
  });

  const formValues = watch();
  const eventId = new URLSearchParams(location.search).get('eventId');

  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      const filtered = clients.filter(client => {
        const matchesAum = client.aum >= (formValues.minAum || 0);
        const matchesIncome = client.income >= (formValues.minIncome || 0);
        const matchesRegion = formValues.regions.length === 0 || 
          formValues.regions.includes(client.region);
        return matchesAum && matchesIncome && matchesRegion;
      });
      setFilteredClients(filtered);
      setCurrentPage(1);
      setIsLoading(false);
    }, 300);
    return () => clearTimeout(timer);
  }, [formValues]);

  const toggleClientSelection = (id: string) => {
    setSelectedClients(prev => 
      prev.includes(id) ? prev.filter(c => c !== id) : [...prev, id]
    );
  };

  const submitNominations = () => {
    if (selectedClients.length === 0) {
      toast.error('Please select at least one client');
      return;
    }
    toast.success(`${selectedClients.length} clients nominated successfully`);
    navigate(`/approval?eventId=${eventId}&clients=${selectedClients.join(',')}`);
  };

  const totalPages = Math.ceil(filteredClients.length / itemsPerPage);
  const paginatedClients = filteredClients.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'nominated': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">
              Client Nomination {eventId && `for Event #${eventId}`}
            </h1>
            <div className="text-sm text-gray-500">
              <Link to="/event-management" className="text-[#002366] hover:underline">
                Event Management
              </Link>
              <span> &gt; Client Nomination</span>
            </div>
          </div>

          <div className="flex flex-col md:flex-row gap-6">
            {/* Filter Panel */}
            <div className="w-full md:w-72 bg-white p-4 rounded-lg shadow">
              <h2 className="font-medium text-[#002366] mb-4">Filter Criteria</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min AUM (SGD)</label>
                  <input
                    type="number"
                    {...register('minAum')}
                    className="w-full p-2 border border-gray-300 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Min Income (SGD)</label>
                  <input
                    type="number"
                    {...register('minIncome')}
                    className="w-full p-2 border border-gray-300 rounded"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Regions</label>
                  <div className="space-y-2">
                    {['Singapore', 'Malaysia', 'Indonesia', 'Thailand'].map(region => (
                      <label key={region} className="flex items-center">
                        <input
                          type="checkbox"
                          value={region}
                          {...register('regions')}
                          className="h-4 w-4 text-[#002366] rounded border-gray-300"
                        />
                        <span className="ml-2 text-sm text-gray-700">{region}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Client List */}
            <div className="flex-1">
              <div className="bg-white rounded-lg shadow overflow-hidden">
                <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                  <h2 className="font-medium text-[#002366]">
                    {filteredClients.length} Clients Found
                  </h2>
                  <button
                    onClick={submitNominations}
                    disabled={selectedClients.length === 0}
                    className="px-4 py-2 bg-[#002366] text-white rounded text-sm font-medium disabled:opacity-50"
                  >
                    Submit Nominations ({selectedClients.length})
                  </button>
                </div>

                {isLoading ? (
                  <div className="p-8 flex justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-[#002366]"></div>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200 text-sm">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Select
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Name
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            AUM (SGD)
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Income (SGD)
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Region
                          </th>
                          <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {paginatedClients.map(client => (
                          <tr key={client.id} className="hover:bg-gray-50">
                            <td className="px-4 py-3 whitespace-nowrap">
                              <input
                                type="checkbox"
                                checked={selectedClients.includes(client.id)}
                                onChange={() => toggleClientSelection(client.id)}
                                className="h-4 w-4 text-[#002366] rounded border-gray-300"
                              />
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap font-medium text-gray-900">
                              {client.name}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {client.aum.toLocaleString()}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {client.income.toLocaleString()}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              {client.region}
                            </td>
                            <td className="px-4 py-3 whitespace-nowrap">
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(client.status)}`}>
                                {client.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
                    <div className="flex-1 flex justify-between items-center">
                      <button
                        onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1 border border-gray-300 rounded text-sm font-medium disabled:opacity-50"
                      >
                        Previous
                      </button>
                      <span className="text-sm text-gray-700">
                        Page {currentPage} of {totalPages}
                      </span>
                      <button
                        onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1 border border-gray-300 rounded text-sm font-medium disabled:opacity-50"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
