import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

type Attendee = {
  id: string;
  client: string;
  checkinTime: Date | null;
  notifiedBanker: boolean;
  seat: string;
  clientType: 'existing' | 'prospect' | 'employee';
};


type Seat = {
  id: string;
  x: number;
  y: number;
};

type VenueMap = {
  image: string;
  seats: Seat[];
};

export default function EventExecution() {
  const location = useLocation();
  const navigate = useNavigate();
  const [attendees, setAttendees] = useState<Attendee[]>([]);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [venueMap, setVenueMap] = useState<VenueMap>({
    image: '',
    seats: []
  });
  const [scale, setScale] = useState(1);

  // 从邀请管理页面接收出席名单
  useEffect(() => {
    // Mock 场地数据
    setVenueMap({
      image: 'https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=conference%20venue%20map%20with%20tables%20and%20seats&sign=a4d733d468849f9ebd38e6502c9703a7',
      seats: [
        { id: 'A-1', x: 100, y: 150 },
        { id: 'A-2', x: 200, y: 150 },
        { id: 'B-1', x: 100, y: 250 },
        { id: 'B-2', x: 200, y: 250 },
      ]
    });

    // 从location.state获取出席名单或使用默认mock数据
    const initialAttendees = location.state?.clients || [
       { id: '1', client: 'Tan Wei Ming', seat: 'A-1', checkinTime: null, notifiedBanker: false, clientType: 'existing' },
       { id: '2', client: 'Lim Jia Hui', seat: 'A-2', checkinTime: null, notifiedBanker: false, clientType: 'prospect' },
       { id: '3', client: 'Wong Chee Meng', seat: 'B-1', checkinTime: null, notifiedBanker: false, clientType: 'existing' },
       { id: '4', client: 'Chen Mei Ling', seat: 'B-2', checkinTime: null, notifiedBanker: false, clientType: 'prospect' }

    ];
    setAttendees(initialAttendees);
  }, [location]);

  const handleCheckIn = (id: string) => {
    const updatedAttendees = attendees.map(attendee => {
      if (attendee.id === id && !attendee.checkinTime) {
        // 播放签到音效
        const audio = new Audio('https://assets.mixkit.co/sfx/preview/mixkit-positive-interface-beep-221.mp3');
        audio.play();
        
        return {
          ...attendee,
          checkinTime: new Date(),
          notifiedBanker: false
        };
      }
      return attendee;
    });
    setAttendees(updatedAttendees);
    toast.success('Check-in recorded');
  };

  const notifyBanker = (id: string) => {
    setAttendees(prev => 
      prev.map(attendee => 
        attendee.id === id ? { ...attendee, notifiedBanker: true } : attendee
      )
    );
    toast.success('Banker notified');
  };

  const goToAnalytics = () => {
    const checkedInAttendees = attendees.filter(a => a.checkinTime);
    navigate('/analytics', { state: { attendees: checkedInAttendees } });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Event Execution</h1>
            <div className="text-sm text-gray-500">
              <span>Event Management &gt; Invitation Management &gt; Event Execution</span>
            </div>
          </div>

          {/* 控制栏 */}
          <div className="bg-white rounded-lg shadow p-4 mb-6 flex justify-between items-center">
            <div className="flex space-x-4">
              <button
                onClick={() => setViewMode('list')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  viewMode === 'list' ? 'bg-[#002366] text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                List View
              </button>
              <button
                onClick={() => setViewMode('map')}
                className={`px-4 py-2 rounded-md text-sm font-medium ${
                  viewMode === 'map' ? 'bg-[#002366] text-white' : 'bg-gray-100 text-gray-700'
                }`}
              >
                Map View
              </button>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-sm">
                <span className="font-medium">Checked In: </span>
                <span className="text-green-600">
                  {attendees.filter(a => a.checkinTime).length}/{attendees.length}
                </span>
              </div>
              <button
                onClick={goToAnalytics}
                className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium"
              >
                View Analytics
              </button>
            </div>
          </div>

          {/* 主要内容区 */}
          {viewMode === 'list' ? (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Client
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Seat
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {attendees.map(attendee => (
                    <tr key={attendee.id} className="hover:bg-gray-50">
                       <td className="px-6 py-4 whitespace-nowrap">
                         <div className="font-medium text-gray-900">{attendee.client}</div>
                         <span className={`text-xs ${
                           attendee.clientType === 'existing' ? 'text-blue-600' :
                           attendee.clientType === 'prospect' ? 'text-purple-600' :
                           'text-green-600'
                         }`}>
                           {attendee.clientType === 'existing' ? 'Existing Client' : 
                            attendee.clientType === 'prospect' ? 'Prospect' : 'Employee'}
                         </span>
                       </td>
                       <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                         {attendee.seat}
                       </td>
                       <td className="px-6 py-4 whitespace-nowrap">

                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          attendee.checkinTime ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                        }`}>
                          {attendee.checkinTime ? 'Checked In' : 'Pending'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                        {!attendee.checkinTime ? (
                          <button
                            onClick={() => handleCheckIn(attendee.id)}
                            className="text-[#002366] hover:text-blue-800"
                          >
                            Check In
                          </button>
                        ) : !attendee.notifiedBanker ? (
                          <button
                            onClick={() => notifyBanker(attendee.id)}
                            className="text-yellow-600 hover:text-yellow-800"
                          >
                            Notify Banker
                          </button>
                        ) : (
                          <span className="text-green-600">Notified</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow p-4 relative overflow-auto">
              <div className="flex justify-between mb-4">
                <h2 className="font-medium text-[#002366]">Venue Map</h2>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setScale(Math.min(2, scale + 0.1))}
                    className="px-2 py-1 bg-gray-100 rounded text-sm"
                  >
                    +
                  </button>
                  <button
                    onClick={() => setScale(Math.max(0.5, scale - 0.1))}
                    className="px-2 py-1 bg-gray-100 rounded text-sm"
                  >
                    -
                  </button>
                </div>
              </div>
              <div className="relative" style={{ transform: `scale(${scale})`, transformOrigin: '0 0' }}>
                {venueMap.image && (
                  <img 
                    src={venueMap.image} 
                    alt="Venue Map" 
                    className="w-full h-auto border border-gray-200"
                  />
                )}
                {venueMap.seats.map(seat => {
                  const attendee = attendees.find(a => a.seat === seat.id);
                  return (
                    <div
                      key={seat.id}
                      className={`absolute w-8 h-8 rounded-full flex items-center justify-center cursor-pointer ${
                        attendee?.checkinTime ? 'bg-green-500' : 'bg-gray-400'
                      }`}
                      style={{ left: `${seat.x}px`, top: `${seat.y}px` }}
                      onClick={() => {
                        if (attendee && !attendee.checkinTime) {
                          handleCheckIn(attendee.id);
                        }
                      }}
                      title={attendee ? attendee.client : 'Empty seat'}
                    >
                      <span className="text-xs text-white font-bold">{seat.id}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 紧急联系浮动按钮 */}
          <button className="fixed bottom-8 right-8 bg-red-500 text-white p-4 rounded-full shadow-lg hover:bg-red-600 transition-colors">
            <i className="fa-solid fa-phone"></i>
          </button>
        </main>
      </div>
    </div>
  );
}
