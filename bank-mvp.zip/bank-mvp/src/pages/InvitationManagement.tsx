import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';
import { clients } from '@/lib/mockData';


type Invitation = {
  id: string;
  client: string;
  sentDate: Date;
  rsvp: boolean | null; // null = no response
  seat: string;
  clientType: 'existing' | 'prospect' | 'employee';
};


type Template = {
  id: string;
  name: string;
  previewUrl: string;
};

export default function InvitationManagement() {
  const location = useLocation();
  const navigate = useNavigate();
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [isSending, setIsSending] = useState(false);

  // Load mock data
  useEffect(() => {
    // Load templates
    setTemplates([
      { id: '1', name: 'Classic Gold', previewUrl: '' },
      { id: '2', name: 'Modern Blue', previewUrl: '' },
      { id: '3', name: 'Luxury Black', previewUrl: '' }
    ]);
    setSelectedTemplate('1');

    // Load invitations from approval center
    const queryParams = new URLSearchParams(location.search);
    const clientIds = queryParams.get('clients')?.split(',') || [];
    
    if (clientIds.length > 0) {
       const newInvitations = clientIds.map((id, index) => {
        const client = clients.find(c => c.id === id);
        return {
          id,
          client: client?.name || `Client ${id}`,
          sentDate: new Date(),
          rsvp: null,
          seat: `T-${index + 1}`,
          clientType: client?.type || 'existing'
        };
      });

      setInvitations(newInvitations);
    } else {
      // Default mock data if no clients passed
      setInvitations([
         { id: '1', client: 'Tan Wei Ming', sentDate: new Date(), rsvp: true, seat: 'A-1', clientType: 'existing' },
         { id: '2', client: 'Lim Jia Hui', sentDate: new Date(), rsvp: false, seat: 'A-2', clientType: 'prospect' },
         { id: '3', client: 'Wong Chee Meng', sentDate: new Date(), rsvp: null, seat: 'B-1', clientType: 'existing' }

      ]);
    }
  }, [location]);

  const handleSendInvitations = () => {
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      toast.success('Invitations sent successfully');
    }, 1500);
  };

  const handleRSVPChange = (id: string, response: boolean) => {
    setInvitations(prev => 
      prev.map(inv => 
        inv.id === id ? { ...inv, rsvp: response } : inv
      )
    );
  };

  const handleSeatChange = (id: string, newSeat: string) => {
    setInvitations(prev => 
      prev.map(inv => 
        inv.id === id ? { ...inv, seat: newSeat } : inv
      )
    );
  };

  const handleFinalize = () => {
    const attendingClients = invitations.filter(inv => inv.rsvp === true);
    if (attendingClients.length === 0) {
      toast.error('No attending clients to finalize');
      return;
    }
    navigate('/execution', { state: { clients: attendingClients } });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Invitation Management</h1>
            <div className="text-sm text-gray-500">
              <span>Event Management &gt; Approval Center &gt; Invitation Management</span>
            </div>
          </div>

          {/* Stats Panel */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Total Invitations</h3>
              <p className="text-2xl font-bold text-[#002366]">{invitations.length}</p>
            </div>
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Confirmed</h3>
              <p className="text-2xl font-bold text-green-600">
                {invitations.filter(inv => inv.rsvp === true).length}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Declined</h3>
              <p className="text-2xl font-bold text-red-600">
                {invitations.filter(inv => inv.rsvp === false).length}
              </p>
            </div>
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-1">Pending</h3>
              <p className="text-2xl font-bold text-yellow-600">
                {invitations.filter(inv => inv.rsvp === null).length}
              </p>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Template Selection */}
            <div className="w-full lg:w-1/4 bg-white rounded-lg shadow p-4">
              <h2 className="font-medium text-[#002366] mb-4">Invitation Templates</h2>
              <div className="space-y-3">
                {templates.map(template => (
                  <motion.div
                    key={template.id}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <div
                      onClick={() => setSelectedTemplate(template.id)}
                      className={`p-3 border rounded-lg cursor-pointer ${
                        selectedTemplate === template.id 
                          ? 'border-yellow-500 bg-yellow-50' 
                          : 'border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      <h3 className="font-medium">{template.name}</h3>
                      <p className="text-xs text-gray-500 mt-1">Click to preview</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <button
                onClick={handleSendInvitations}
                disabled={isSending || invitations.length === 0}
                className="mt-4 w-full px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium disabled:opacity-50"
              >
                {isSending ? 'Sending...' : 'Send All Invitations'}
              </button>
            </div>

            {/* Invitation Preview */}
            <div className="flex-1 bg-white rounded-lg shadow p-6 border-2 border-yellow-400">
              <h2 className="font-medium text-[#002366] mb-4">Invitation Preview</h2>
              <div className="bg-white p-8 min-h-[400px] font-serif text-[11pt]">
                <div className="border-b border-gray-200 pb-4 mb-4">
                  <h1 className="text-2xl font-bold text-[#002366] mb-2">Private Banking Event</h1>
                  <p className="text-gray-600">An exclusive gathering for our valued clients</p>
                </div>
                <div className="mb-6">
                  <p className="mb-4">Dear Valued Client,</p>
                  <p className="mb-4">
                    We are pleased to invite you to our exclusive Private Banking Event at Marina Bay Sands on June 15, 2025.
                  </p>
                  <p className="mb-4">
                    This event will feature insights from our top investment strategists and networking opportunities with other high-net-worth individuals.
                  </p>
                  <p className="mb-4">
                    Kindly RSVP by May 30, 2025 to confirm your attendance.
                  </p>
                </div>
                <div className="border-t border-gray-200 pt-4">
                  <p className="font-bold">Sincerely,</p>
                  <p>Private Banking Team</p>
                </div>
              </div>
            </div>

            {/* RSVP List */}
            <div className="w-full lg:w-1/3 bg-white rounded-lg shadow p-4">
              <h2 className="font-medium text-[#002366] mb-4">RSVP Status</h2>
              <div className="space-y-3">
                {invitations.map(invitation => (
                  <div key={invitation.id} className="border border-gray-200 rounded-lg p-3">
                     <div className="flex justify-between items-center mb-2">
                       <div>
                         <h3 className="font-medium">{invitation.client}</h3>
                         <span className={`text-xs ${
                           invitation.clientType === 'existing' ? 'text-blue-600' :
                           invitation.clientType === 'prospect' ? 'text-purple-600' :
                           'text-green-600'
                         }`}>
                           {invitation.clientType === 'existing' ? 'Existing Client' : 
                            invitation.clientType === 'prospect' ? 'Prospect' : 'Employee'}
                         </span>
                       </div>
                       <input
                         type="text"
                         value={invitation.seat}
                         onChange={(e) => handleSeatChange(invitation.id, e.target.value)}
                         className="w-16 text-center border border-gray-300 rounded text-sm p-1"
                       />
                     </div>

                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleRSVPChange(invitation.id, true)}
                        className={`px-2 py-1 text-xs rounded ${
                          invitation.rsvp === true ? 'bg-green-500 text-white' : 'bg-gray-100'
                        }`}
                      >
                        Accept
                      </button>
                      <button
                        onClick={() => handleRSVPChange(invitation.id, false)}
                        className={`px-2 py-1 text-xs rounded ${
                          invitation.rsvp === false ? 'bg-red-500 text-white' : 'bg-gray-100'
                        }`}
                      >
                        Decline
                      </button>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Sent: {invitation.sentDate.toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
              <button
                onClick={handleFinalize}
                disabled={invitations.filter(inv => inv.rsvp === true).length === 0}
                className="mt-4 w-full px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium disabled:opacity-50"
              >
                Finalize Attendance
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
