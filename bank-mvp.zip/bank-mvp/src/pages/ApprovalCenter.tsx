import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';
import { clients } from '@/lib/mockData';


type ApprovalItem = {
  id: string;
  clientName: string;
  banker: string;
  level: number;
  status: 'pending' | 'approved' | 'rejected';
  clientType: 'existing' | 'prospect' | 'employee';
};


type SeatsData = {
  total: number;
  allocated: number;
  remaining: number;
};

export default function ApprovalCenter() {
  const location = useLocation();
  const navigate = useNavigate();
  const [approvalItems, setApprovalItems] = useState<ApprovalItem[]>([]);
  const [seats, setSeats] = useState<SeatsData>({ total: 50, allocated: 0, remaining: 50 });
  const [currentLevel, setCurrentLevel] = useState(1);

  // 从URL参数获取提名客户
  useEffect(() => {
    const queryParams = new URLSearchParams(location.search);
    const clientIds = queryParams.get('clients')?.split(',') || [];
    const eventId = queryParams.get('eventId');

    if (clientIds.length > 0) {
       const newItems = clientIds.map(id => {
        const client = clients.find(c => c.id === id);
        return {
          id,
          clientName: client?.name || `Client ${id}`,
          banker: 'Banker Name',
          level: 1,
          status: 'pending' as const,
          clientType: client?.type || 'existing'
        };
      });

      setApprovalItems(newItems);
    }
  }, [location]);

  const handleApprove = (id: string) => {
    setApprovalItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, status: 'approved', level: currentLevel + 1 } : item
      )
    );
    setSeats(prev => ({
      ...prev,
      allocated: prev.allocated + 1,
      remaining: prev.remaining - 1
    }));
    toast.success('Client approved');
  };

  const handleReject = (id: string) => {
    setApprovalItems(prev => 
      prev.map(item => 
        item.id === id ? { ...item, status: 'rejected' } : item
      )
    );
    toast.error('Client rejected');
  };

  const handleFinalize = () => {
    const approvedClients = approvalItems.filter(item => item.status === 'approved');
    if (approvedClients.length === 0) {
      toast.error('No approved clients to finalize');
      return;
    }
    const queryParams = new URLSearchParams();
    queryParams.set('clients', approvedClients.map(c => c.id).join(','));
    navigate(`/invitation?${queryParams.toString()}`);
    toast.success('Approved clients sent to invitation management');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const pendingItems = approvalItems.filter(item => item.status === 'pending');
  const approvedItems = approvalItems.filter(item => item.status === 'approved');
  const rejectedItems = approvalItems.filter(item => item.status === 'rejected');

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Approval Center</h1>
            <div className="text-sm text-gray-500">
              <span>Event Management &gt; Client Nomination &gt; Approval Center</span>
            </div>
          </div>

          {/* Approval Progress */}
          <div className="bg-white rounded-lg shadow p-6 mb-8">
            <h2 className="font-medium text-[#002366] mb-4">Approval Progress</h2>
            <div className="flex items-center justify-between mb-4">
              {[1, 2, 3].map(level => (
                <div key={level} className="flex flex-col items-center">
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center 
                      ${currentLevel >= level ? 'bg-[#002366] text-white' : 'bg-gray-200'}`}
                  >
                    {level}
                  </div>
                  <span className="text-xs mt-1">Level {level}</span>
                </div>
              ))}
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-[#002366] h-2.5 rounded-full" 
                style={{ width: `${(currentLevel / 3) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Approval Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {/* Pending Column */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium text-[#002366] mb-4 flex items-center">
                <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                PENDING ({pendingItems.length})
              </h3>
              {pendingItems.length > 0 ? (
                pendingItems.map(item => (
                  <div key={item.id} className="mb-4 p-3 border border-gray-200 rounded-lg">
                     <div className="flex justify-between items-start mb-2">
                       <h4 className="font-medium">{item.clientName}</h4>
                       <span className="text-xs text-gray-500">Level {item.level}</span>
                     </div>
                     <p className="text-sm text-gray-600">Nominated by: {item.banker}</p>
                     <p className="text-xs mb-2">
                       <span className={`px-1 py-0.5 rounded ${
                         item.clientType === 'existing' ? 'bg-blue-100 text-blue-800' :
                         item.clientType === 'prospect' ? 'bg-purple-100 text-purple-800' :
                         'bg-green-100 text-green-800'
                       }`}>
                         {item.clientType === 'existing' ? 'Existing Client' : 
                          item.clientType === 'prospect' ? 'Prospect' : 'Employee'}
                       </span>
                     </p>
                     <div className="flex space-x-2">

                      <button 
                        onClick={() => handleApprove(item.id)}
                        className="px-3 py-1 bg-green-500 text-white text-xs rounded"
                      >
                        Approve
                      </button>
                      <button 
                        onClick={() => handleReject(item.id)}
                        className="px-3 py-1 bg-red-500 text-white text-xs rounded"
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No pending items</p>
              )}
            </div>

            {/* Approved Column */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium text-[#002366] mb-4 flex items-center">
                <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                APPROVED ({approvedItems.length})
              </h3>
              {approvedItems.length > 0 ? (
                approvedItems.map(item => (
                  <div key={item.id} className="mb-4 p-3 border border-gray-200 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{item.clientName}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(item.status)}`}>
                        {item.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">Nominated by: {item.banker}</p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No approved items</p>
              )}
            </div>

            {/* Rejected Column */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium text-[#002366] mb-4 flex items-center">
                <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                REJECTED ({rejectedItems.length})
              </h3>
              {rejectedItems.length > 0 ? (
                rejectedItems.map(item => (
                  <div key={item.id} className="mb-4 p-3 border border-gray-200 rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium">{item.clientName}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(item.status)}`}>
                        {item.status.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">Nominated by: {item.banker}</p>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500">No rejected items</p>
              )}
            </div>
          </div>

          {/* Seats Management */}
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="font-medium text-[#002366] mb-4">Seats Management</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">Total Seats</h3>
                <p className="text-2xl font-bold text-[#002366]">{seats.total}</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">Allocated</h3>
                <p className="text-2xl font-bold text-green-800">{seats.allocated}</p>
              </div>
              <div className="bg-yellow-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">Remaining</h3>
                <p className="text-2xl font-bold text-yellow-800">{seats.remaining}</p>
              </div>
            </div>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adjust Total Seats: {seats.total}
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={seats.total}
                onChange={(e) => {
                  const newTotal = parseInt(e.target.value);
                  setSeats({
                    total: newTotal,
                    allocated: seats.allocated,
                    remaining: newTotal - seats.allocated
                  });
                }}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>
            <div className="flex justify-end">
              <button
                onClick={handleFinalize}
                disabled={approvedItems.length === 0}
                className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium disabled:opacity-50"
              >
                Finalize and Send to Invitation
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
