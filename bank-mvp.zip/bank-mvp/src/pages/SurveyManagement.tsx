import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

type Survey = {
  id: string;
  title: string;
  sentDate: string;
  responses: number;
  averageRating: number;
};

export default function SurveyManagement() {
  const [surveys, setSurveys] = useState<Survey[]>([
    {
      id: '1',
      title: 'Wealth Management Forum Feedback',
      sentDate: '2025-06-16',
      responses: 42,
      averageRating: 4.2
    },
    {
      id: '2',
      title: 'Private Investment Roundtable Feedback',
      sentDate: '2025-07-21',
      responses: 35,
      averageRating: 4.5
    }
  ]);

  const sendNewSurvey = () => {
    const newSurvey = {
      id: (surveys.length + 1).toString(),
      title: `Event Feedback Survey ${surveys.length + 1}`,
      sentDate: new Date().toISOString().split('T')[0],
      responses: 0,
      averageRating: 0
    };
    setSurveys([...surveys, newSurvey]);
    toast.success('Survey sent successfully');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Survey Management</h1>
            <button
              onClick={sendNewSurvey}
              className="px-4 py-2 bg-[#002366] text-white rounded-md text-sm font-medium"
            >
              Send New Survey
            </button>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Survey Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Sent Date
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Responses
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Average Rating
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {surveys.map(survey => (
                  <tr key={survey.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{survey.title}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {survey.sentDate}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {survey.responses}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="w-16 bg-gray-200 rounded-full h-2.5 mr-2">
                          <div 
                            className="bg-yellow-500 h-2.5 rounded-full" 
                            style={{ width: `${(survey.averageRating / 5) * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{survey.averageRating.toFixed(1)}/5</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button 
                        onClick={() => toast.success(`Survey ${survey.title} details viewed`)}
                        className="text-[#002366] hover:text-blue-800 mr-4"
                      >
                        View
                      </button>
                      <button 
                        onClick={() => toast.success(`Survey ${survey.title} results exported`)}
                        className="text-green-600 hover:text-green-800"
                      >
                        Export
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
}
