import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

export default function CompletedTasks() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Completed Tasks</h1>
          </div>
          
          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-lg font-medium text-[#002366] mb-4">Completed Event Tasks</h2>
            <div className="space-y-4">
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Wealth Management Forum</h3>
                    <p className="text-sm text-gray-600">Completed on June 15, 2025</p>
                  </div>
                  <button 
                    onClick={() => toast.success('Task details viewed')}
                    className="px-3 py-1 bg-[#002366] text-white rounded text-sm"
                  >
                    View Details
                  </button>
                </div>
              </div>
              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">Private Investment Roundtable</h3>
                    <p className="text-sm text-gray-600">Completed on July 20, 2025</p>
                  </div>
                  <button 
                    onClick={() => toast.success('Task details viewed')}
                    className="px-3 py-1 bg-[#002366] text-white rounded text-sm"
                  >
                    View Details
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}