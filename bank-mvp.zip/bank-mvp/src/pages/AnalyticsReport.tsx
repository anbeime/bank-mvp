import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BarChart, PieChart, LineChart, Bar, Pie, Line, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

type AttendanceData = {
  date: string;
  attendanceRate: number;
  clientTiers: {
    platinum: number;
    gold: number;
    silver: number;
  };
  clientTypes: {
    existing: number;
    prospect: number;
    employee: number;
  };
};


type FeedbackData = {
  question: string;
  averageScore: number;
};

type ROIData = {
  cost: number;
  revenue: number;
  roi: number;
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

export default function AnalyticsReport() {
  const location = useLocation();
  const navigate = useNavigate();
  const [dateRange, setDateRange] = useState({
    start: '2025-05-01',
    end: '2025-05-31'
  });
  const [attendanceData, setAttendanceData] = useState<AttendanceData[]>([]);
  const [feedbackData, setFeedbackData] = useState<FeedbackData[]>([]);
  const [roiData, setRoiData] = useState<ROIData>({
    cost: 0,
    revenue: 0,
    roi: 0
  });
  const [compareMode, setCompareMode] = useState(false);
  const [compareData, setCompareData] = useState<AttendanceData[]>([]);

  // 从活动执行页面接收数据或使用默认mock数据
  useEffect(() => {
     const initialData = location.state?.attendanceData || [
       {
         date: '2025-05-15',
         attendanceRate: 0.85,
         clientTiers: {
           platinum: 12,
           gold: 25,
           silver: 18
         },
         clientTypes: {
           existing: 30,
           prospect: 15,
           employee: 10
         }
       },
       {
         date: '2025-05-20',
         attendanceRate: 0.78,
         clientTiers: {
           platinum: 15,
           gold: 22,
           silver: 20
         },
         clientTypes: {
           existing: 35,
           prospect: 12,
           employee: 10
         }
       },
       {
         date: '2025-05-25',
         attendanceRate: 0.92,
         clientTiers: {
           platinum: 18,
           gold: 30,
           silver: 22
         },
         clientTypes: {
           existing: 40,
           prospect: 20,
           employee: 10
         }
       }
     ];


    const initialFeedback = location.state?.feedbackData || [
      { question: '活动内容满意度', averageScore: 4.5 },
      { question: '演讲者表现', averageScore: 4.2 },
      { question: '场地设施', averageScore: 4.0 },
      { question: '餐饮服务', averageScore: 3.8 }
    ];

    const initialROI = location.state?.roiData || {
      cost: 25000,
      revenue: 75000,
      roi: 2.0
    };

    setAttendanceData(initialData);
    setFeedbackData(initialFeedback);
    setRoiData(initialROI);
  }, [location]);

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setDateRange(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleExport = (format: 'json' | 'csv' | 'pdf') => {
    toast.success(`报告导出成功 (${format.toUpperCase()})`);
    // 模拟导出功能
    if (format === 'json') {
      const blob = new Blob([JSON.stringify({ attendanceData, feedbackData, roiData })], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'event-analytics-report.json';
      a.click();
      URL.revokeObjectURL(url);
    }
    // 其他格式导出可以在这里扩展
  };

  const toggleCompareMode = () => {
    if (compareMode) {
      setCompareMode(false);
    } else {
      // 模拟对比数据
      setCompareData([
        {
          date: '2025-05-15',
          attendanceRate: 0.75,
          clientTiers: {
            platinum: 10,
            gold: 20,
            silver: 15
          }
        },
        {
          date: '2025-05-20',
          attendanceRate: 0.82,
          clientTiers: {
            platinum: 12,
            gold: 25,
            silver: 18
          }
        },
        {
          date: '2025-05-25',
          attendanceRate: 0.88,
          clientTiers: {
            platinum: 15,
            gold: 28,
            silver: 20
          }
        }
      ]);
      setCompareMode(true);
    }
  };

  const clientTierData = [
     { name: 'Platinum', value: attendanceData.reduce((sum, item) => sum + item.clientTiers.platinum, 0) },
     { name: 'Gold', value: attendanceData.reduce((sum, item) => sum + item.clientTiers.gold, 0) },
     { name: 'Silver', value: attendanceData.reduce((sum, item) => sum + item.clientTiers.silver, 0) }
   ];

   const clientTypeData = [
     { name: 'Existing Clients', value: attendanceData.reduce((sum, item) => sum + item.clientTypes.existing, 0) },
     { name: 'Prospects', value: attendanceData.reduce((sum, item) => sum + item.clientTypes.prospect, 0) },
     { name: 'Employees', value: attendanceData.reduce((sum, item) => sum + item.clientTypes.employee, 0) }
   ];


  const filteredAttendanceData = attendanceData.filter(item => {
    const itemDate = new Date(item.date);
    const startDate = new Date(dateRange.start);
    const endDate = new Date(dateRange.end);
    return itemDate >= startDate && itemDate <= endDate;
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">活动分析报告</h1>
            <div className="flex items-center space-x-4">
              <div className="flex space-x-2">
                <input
                  type="date"
                  name="start"
                  value={dateRange.start}
                  onChange={handleDateChange}
                  className="p-2 border border-gray-300 rounded text-sm"
                />
                <span className="flex items-center">至</span>
                <input
                  type="date"
                  name="end"
                  value={dateRange.end}
                  onChange={handleDateChange}
                  className="p-2 border border-gray-300 rounded text-sm"
                />
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleExport('json')}
                  className="px-3 py-2 bg-[#002366] text-white rounded-md text-sm font-medium"
                >
                  JSON
                </button>
                <button
                  onClick={() => handleExport('csv')}
                  className="px-3 py-2 bg-green-600 text-white rounded-md text-sm font-medium"
                >
                  CSV
                </button>
                <button
                  onClick={toggleCompareMode}
                  className={`px-3 py-2 rounded-md text-sm font-medium ${
                    compareMode ? 'bg-purple-600 text-white' : 'bg-gray-200 text-gray-700'
                  }`}
                >
                  {compareMode ? '退出对比' : '数据对比'}
                </button>
              </div>
            </div>
          </div>

          {/* 出席率统计 */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-lg font-semibold text-[#002366] mb-4">出席率趋势</h2>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={filteredAttendanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="attendanceRate" 
                      stroke="#002366" 
                      name="出席率" 
                      strokeWidth={2}
                      activeDot={{ r: 8 }}
                    />
                    {compareMode && (
                      <Line 
                        type="monotone" 
                        dataKey="attendanceRate" 
                        stroke="#8884d8" 
                        name="对比数据" 
                        strokeWidth={2}
                        data={compareData}
                      />
                    )}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

             <div className="bg-white p-6 rounded-lg shadow">
               <h2 className="text-lg font-semibold text-[#002366] mb-4">客户类型分布</h2>
               <div className="h-80">
                 <ResponsiveContainer width="100%" height="100%">
                   <PieChart>
                     <Pie
                       data={clientTypeData}
                       cx="50%"
                       cy="50%"
                       labelLine={false}
                       outerRadius={80}
                       fill="#8884d8"
                       dataKey="value"
                       label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                     >
                       {clientTypeData.map((entry, index) => (
                         <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                       ))}
                     </Pie>
                     <Tooltip />
                     <Legend />
                   </PieChart>
                 </ResponsiveContainer>
               </div>
             </div>

          </div>

          {/* 反馈分析 */}
          <div className="bg-white p-6 rounded-lg shadow mb-8">
            <h2 className="text-lg font-semibold text-[#002366] mb-4">客户反馈分析</h2>
            <div className="space-y-4">
              {feedbackData.map((item, index) => (
                <div key={index} className="border-b border-gray-100 pb-4 last:border-0">
                  <div className="flex justify-between items-center mb-1">
                    <h3 className="font-medium">{item.question}</h3>
                    <span className="text-sm font-medium text-[#002366]">
                      {item.averageScore.toFixed(1)}/5
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-[#002366] h-2 rounded-full"
                      style={{ width: `${(item.averageScore / 5) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ROI分析 */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-lg font-semibold text-[#002366] mb-4">ROI分析</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">总成本 (SGD)</h3>
                <p className="text-2xl font-bold text-[#002366]">
                  {roiData.cost.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 mt-1">同比上月: +5%</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">预期收益 (SGD)</h3>
                <p className="text-2xl font-bold text-green-800">
                  {roiData.revenue.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 mt-1">同比上月: +12%</p>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-1">投资回报率</h3>
                <p className="text-2xl font-bold text-purple-800">
                  {roiData.roi.toFixed(1)}x
                </p>
                <p className="text-xs text-gray-500 mt-1">行业平均: 1.8x</p>
              </div>
            </div>
            <div className="mt-4">
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-[#002366] h-2.5 rounded-full"
                  style={{ width: `${Math.min(100, (roiData.roi / 3) * 100)}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>0x</span>
                <span>1x</span>
                <span>2x</span>
                <span>3x</span>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
