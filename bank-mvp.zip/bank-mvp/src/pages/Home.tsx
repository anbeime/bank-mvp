export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-900 to-blue-950 text-white p-8">
      <header className="mb-12">
        <h1 className="text-4xl font-bold mb-4">新加坡银行客户事件管理系统</h1>
        <p className="text-xl text-blue-200">
          优化私人银行客户活动的全流程数字化管理平台
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* 活动管理卡片 */}
        <a href="/event-management" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">活动管理</h2>
          <p className="text-blue-100 mb-4">
            创建和编辑活动，设置客户筛选标准，广播活动通知
          </p>
        </a>

        {/* 客户提名卡片 */}
        <a href="/nomination" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">客户提名</h2>
          <p className="text-blue-100 mb-4">
            筛选客户并提交提名，跟踪审批状态
          </p>
        </a>

        {/* 审批中心卡片 */}
        <a href="/approval" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">审批中心</h2>
          <p className="text-blue-100 mb-4">
            多级审批流程管理，席位分配与最终名单确认
          </p>
        </a>

        {/* 邀请管理卡片 */}
        <a href="/invitation" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">邀请管理</h2>
          <p className="text-blue-100 mb-4">
            发送邀请函，跟踪客户RSVP状态，管理座位分配
          </p>
        </a>

        {/* 活动执行卡片 */}
        <a href="/execution" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">活动执行</h2>
          <p className="text-blue-100 mb-4">
            现场签到管理，座位引导，实时通知银行家
          </p>
        </a>

        {/* 数据分析卡片 */}
        <a href="/analytics-report" className="bg-blue-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow">
          <h2 className="text-2xl font-semibold mb-4">数据分析</h2>
          <p className="text-blue-100 mb-4">
            活动效果评估，客户参与度分析，ROI计算
          </p>
        </a>
      </div>
    </div>
  );
}