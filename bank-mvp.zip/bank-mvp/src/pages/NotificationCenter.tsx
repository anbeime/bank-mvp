import { useState } from 'react';
import Navbar from '@/components/Navbar';
import Sidebar from '@/components/Sidebar';
import { toast } from 'sonner';

type Notification = {
  id: string;
  type: 'approval' | 'reminder' | 'checkin';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  recipient: string;
};

export default function NotificationCenter() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'approval',
      title: 'New Nomination for Approval',
      message: 'John Tan has nominated 3 clients for Wealth Forum',
      timestamp: '2025-06-10 09:30',
      read: false,
      recipient: 'Team Lead'
    },
    {
      id: '2',
      type: 'reminder',
      title: 'Event Reminder',
      message: 'Wealth Management Forum starts in 2 days',
      timestamp: '2025-06-13 14:15',
      read: false,
      recipient: 'All Bankers'
    },
    {
      id: '3',
      type: 'checkin',
      title: 'Client Checked In',
      message: 'Tan Wei Ming has arrived at the event venue',
      timestamp: '2025-06-15 10:05',
      read: true,
      recipient: 'John Tan'
    }
  ]);

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(notif =>
        notif.id === id ? { ...notif, read: true } : notif
      )
    );
    toast.success('Notification marked as read');
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'approval': return 'bg-blue-100 text-blue-800';
      case 'reminder': return 'bg-yellow-100 text-yellow-800';
      case 'checkin': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-[#002366]">Notification Center</h1>
            <div className="text-sm text-gray-500">
              {notifications.filter(n => !n.read).length} unread notifications
            </div>
          </div>

          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Type
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Title
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Message
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Recipient
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {notifications.map(notification => (
                  <tr 
                    key={notification.id} 
                    className={notification.read ? 'bg-white' : 'bg-blue-50'}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(notification.type)}`}>
                        {notification.type}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                      {notification.title}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      {notification.message}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {notification.recipient}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {notification.timestamp}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {!notification.read ? (
                        <button
                          onClick={() => markAsRead(notification.id)}
                          className="px-3 py-1 bg-[#002366] text-white rounded text-sm"
                        >
                          Mark as Read
                        </button>
                      ) : (
                        <span className="text-sm text-gray-500">Read</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </main>
      </div>
    </div>
  );
}
