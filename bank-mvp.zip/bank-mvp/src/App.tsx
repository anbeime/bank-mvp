import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import EventManagement from "@/pages/EventManagement";
import ClientNomination from "@/pages/ClientNomination";
import ApprovalCenter from "@/pages/ApprovalCenter";
import InvitationManagement from "@/pages/InvitationManagement";
import EventExecution from "@/pages/EventExecution";
import AnalyticsReport from "@/pages/AnalyticsReport";
import CompletedTasks from "@/pages/CompletedTasks";
import SurveyManagement from "@/pages/SurveyManagement";
import NotificationCenter from "@/pages/NotificationCenter";
import { createContext, useState } from "react";

export const AuthContext = createContext({
  isAuthenticated: false,
  setIsAuthenticated: (value: boolean) => {},
  logout: () => {},
});

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/event-management" element={<EventManagement />} />
        <Route path="/nomination" element={<ClientNomination />} />
        <Route path="/approval" element={<ApprovalCenter />} />
        <Route path="/invitation" element={<InvitationManagement />} />
        <Route path="/execution" element={<EventExecution />} />
        <Route path="/analytics" element={<div className="text-center text-xl">Analytics & Reports - Coming Soon</div>} />
        <Route path="/analytics-report" element={<AnalyticsReport />} />
        <Route path="/completed-tasks" element={<CompletedTasks />} />
        <Route path="/survey" element={<SurveyManagement />} />
        <Route path="/notifications" element={<NotificationCenter />} />
      </Routes>
    </AuthContext.Provider>
  );
}

