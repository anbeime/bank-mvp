export interface Event {
  id: string;
  title: string;
  date: string;
  location: string;
  criteria: {
    aum: number;
    income: number;
  };
}

export interface Client {
  id: string;
  name: string;
  aum: number;
  income: number;
  status: 'eligible' | 'nominated' | 'approved' | 'rejected';
  region: string;
  type: 'existing' | 'prospect' | 'employee';
}


export interface Banker {
  id: string;
  name: string;
  team: string;
}

export const events: Event[] = [
  {
    id: '1',
    title: 'Wealth Management Forum',
    date: '2025-06-15',
    location: 'Marina Bay Sands, Singapore',
    criteria: {
      aum: 5000000,
      income: 500000
    }
  },
  {
    id: '2',
    title: 'Private Investment Roundtable',
    date: '2025-07-20',
    location: 'Raffles Hotel, Singapore',
    criteria: {
      aum: 2000000,
      income: 300000
    }
  }
];

export const bankers: Banker[] = [
  { id: '1', name: 'John Tan', team: 'Wealth Management' },
  { id: '2', name: 'Sarah Lim', team: 'Private Banking' },
  { id: '3', name: 'Michael Wong', team: 'Investment Advisory' },
  { id: '4', name: 'Emily Chen', team: 'Wealth Management' },
  { id: '5', name: 'David Koh', team: 'Private Banking' },
  { id: '6', name: 'Jessica Lee', team: 'Investment Advisory' }

];



export const clients: Client[] = [
  {
    id: '1',
    name: 'Tan Wei Ming',
    aum: 8500000,
    income: 1200000,
    status: 'eligible',
    region: 'Singapore',
    type: 'existing'
  },
  {
    id: '2',
    name: 'Lim Jia Hui',
    aum: 3200000,
    income: 450000,
    status: 'eligible',
    region: 'Malaysia',
    type: 'prospect'
  },
  {
    id: '3',
    name: 'Wong Chee Meng',
    aum: 15000000,
    income: 2500000,
    status: 'nominated',
    region: 'Singapore',
    type: 'existing'
  },
  {
    id: '4',
    name: 'Chen Mei Ling',
    aum: 2800000,
    income: 380000,
    status: 'eligible',
    region: 'Indonesia',
    type: 'prospect'
  },
  {
    id: '5',
    name: 'Koh Boon Kiat',
    aum: 7500000,
    income: 950000,
    status: 'approved',
    region: 'Singapore',
    type: 'employee'
  },
  {
    id: '6',
    name: 'Lee Siok Hui',
    aum: 4200000,
    income: 520000,
    status: 'rejected',
    region: 'Thailand',
    type: 'existing'
  }
];


