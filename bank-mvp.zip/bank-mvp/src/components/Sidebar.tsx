import { Link } from 'react-router-dom';

export default function Sidebar() {
  return (
    <div className="flex flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-gray-200 bg-white">
        <div className="h-0 flex-1 flex flex-col pt-5 pb-4 overflow-y-auto">
          <nav className="flex-1 px-2 space-y-1">
            <Link
              to="/event-management"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md bg-blue-50 text-[#002366]"
            >
              <i className="fa-solid fa-calendar-days mr-3 text-[#002366]"></i>
              Event Management
            </Link>
            <Link
              to="/nomination"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-users mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Client Nomination
            </Link>
            <Link
              to="/approval"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-check-double mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Approval Center
            </Link>
            <Link
              to="/invitation"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-envelope mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Invitation Management
            </Link>
            <Link
              to="/execution"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-clipboard-check mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Event Execution
            </Link>
            <Link
              to="/analytics-report"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-chart-line mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Analytics & Reports
            </Link>
            <Link
              to="/completed-tasks"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-check-circle mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Completed Tasks
            </Link>
            <Link
              to="/notifications"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-bell mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Notifications
            </Link>
            <Link
              to="/survey"
              className="group flex items-center px-2 py-2 text-sm font-medium rounded-md text-gray-600 hover:bg-blue-50 hover:text-[#002366]"
            >
              <i className="fa-solid fa-clipboard-question mr-3 text-gray-400 group-hover:text-[#002366]"></i>
              Surveys
            </Link>
          </nav>
        </div>
        <div className="flex-shrink-0 flex border-t border-gray-200 p-4">
          <div className="flex items-center">
            <div>
              <span className="inline-block h-10 w-10 rounded-full bg-blue-100 text-[#002366] flex items-center justify-center">
                <i className="fa-solid fa-user"></i>
              </span>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">Banker Name</p>
              <p className="text-xs font-medium text-gray-500">Private Banking</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
